package com.example.streetlights2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;
import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;

public class ControlActivity extends AppCompatActivity {

    Button btnShowFaulty, btnShowRepaired, btnBackToMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_control);

        btnShowFaulty = findViewById(R.id.btnShowFaulty);
        btnShowRepaired = findViewById(R.id.btnShowRepaired);
        btnBackToMap = findViewById(R.id.btnBackToMap);

        btnShowFaulty.setOnClickListener(v -> {
            Toast.makeText(ControlActivity.this, "Displaying Faulty Street Lights", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(ControlActivity.this, MapsActivity.class);
            intent.putExtra("showType", "faulty");
            startActivity(intent);
        });

        btnShowRepaired.setOnClickListener(v -> {
            Toast.makeText(ControlActivity.this, "Displaying Recently Repaired Lights", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(ControlActivity.this, MapsActivity.class);
            intent.putExtra("showType", "repaired");
            startActivity(intent);
        });

        btnBackToMap.setOnClickListener(v -> {
            Intent intent = new Intent(ControlActivity.this, MapsActivity.class);
            startActivity(intent);
        });

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                moveTaskToBack(true);  // Minimize app instead of logging out
            }
        });
    }
}