// Updated MapsActivity.java
package com.example.streetlights2;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class MapsActivity extends AppCompatActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private FusedLocationProviderClient fusedLocationProviderClient;
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);

        ImageButton btnToggleMapType = findViewById(R.id.btnToggleMapType);
        Button btnHome = findViewById(R.id.btnHome);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        if (mapFragment != null) mapFragment.getMapAsync(this);

        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);

        btnToggleMapType.setOnClickListener(v -> toggleMapType());
        btnHome.setOnClickListener(v -> {
            Intent intent = new Intent(MapsActivity.this, ControlActivity.class);
            startActivity(intent);
            finish();
        });

        getCurrentLocation();
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        mMap = googleMap;
        handleIncomingIntent();
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_PERMISSION_REQUEST_CODE);
            return;
        }
        mMap.setMyLocationEnabled(true);
        mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
    }

    private void handleIncomingIntent() {
        String showType = getIntent().getStringExtra("showType");
        if (showType != null) {
            if (showType.equals("faulty")) {
                Toast.makeText(this, "Showing Faulty Street Lights", Toast.LENGTH_SHORT).show();
                // Add logic to display faulty lights markers here
            } else if (showType.equals("repaired")) {
                Toast.makeText(this, "Showing Repaired Street Lights", Toast.LENGTH_SHORT).show();
                // Add logic to display repaired lights markers here
            }
        }
    }

    @SuppressLint("MissingPermission")
    private void getCurrentLocation() {
        fusedLocationProviderClient.getLastLocation()
                .addOnSuccessListener(this, location -> {
                    if (location != null) updateMapLocation(location);
                })
                .addOnFailureListener(e -> Toast.makeText(this, "Location not available", Toast.LENGTH_SHORT).show());
    }

    private void updateMapLocation(@NonNull Location location) {
        LatLng userLocation = new LatLng(location.getLatitude(), location.getLongitude());
        mMap.clear();
        mMap.addMarker(new MarkerOptions().position(userLocation).title("Your Location"));
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(userLocation, 15));
    }

    private void toggleMapType() {
        if (mMap != null) {
            mMap.setMapType(mMap.getMapType() == GoogleMap.MAP_TYPE_NORMAL ?
                    GoogleMap.MAP_TYPE_HYBRID : GoogleMap.MAP_TYPE_NORMAL);
        }
    }
}
